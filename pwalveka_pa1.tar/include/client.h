#ifndef CLIENT_H_
#define CLIENT_H_

int connect_to_host(char *server_ip, int server_port);
int client_starter_function(int argc, char **argv);

#endif