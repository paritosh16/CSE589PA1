#ifndef SERVER_H_
#define SERVER_H_

int server_starter_function(int argc, char **argv);

#endif